<?php
session_start();
if (!isset($_SESSION['poziom_uprawnien']) || $_SESSION['poziom_uprawnien'] !== 'administrator') {
    header("Location: ../../../index.php"); // Brak dostępu
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel administracyjny</title>
    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../../../css/admin.css">
</head>
<body>
    <header>
            <nav>
                <ul>
                    <li><a href="/Biblioteka/index.php">Strona Główna</a></li>
                    <li><a href="/Biblioteka/php/reservation.php">Rezerwacja Książek</a></li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <!-- if użytkownik jest zalogowany, wyświetl "Wyloguj" -->
                        <li><a href="/Biblioteka/php/logout.php" id="logoutBtn">Wyloguj się</a></li>
                    <?php else: ?>
                        <!-- if użytkownik nie jest zalogowany, wyświetl "Zaloguj się" -->
                        <li><a href="/Biblioteka/php/login.php">Zaloguj się</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
    </header>   

    <section id="pasek">
        <ul>
            <li><a href="../formularze/czytelnik_formularz.php"><button>Formularze</button></a></li>
            <li><button disabled>Tabele</button></li>
        </ul>
    </section>

    <section id="panel">
        <ul>
                   
            <li><a href="autor_tabela.php"><button>Autor</button></a></li>
            <li><a href="autor_ksiazki_tabela.php"><button>Autor-Książka</button></li>
            <li><a href="czytelnik_tabela.php"><button disabled>Czytelnik</button></a></li>
            <li><a href="egzemplarz_tabela.php"><button>Egzemplarz</button></a></li>
            <li><a href="gatunek_tabela.php"><button>Gatunek</button></a></li>
            <li><a href="gatunek_ksiazki_tabela.php"><button>Gatunek-Książka</button></a></li>
            <li><a href="ksiazka_tabela.php"><button>Książka</button></a></li>
            <li><a href="pracownik_tabela.php"><button>Pracownik</button></a></li>
            <li><a href="rezerwacja_tabela.php"><button>Rezerwacja</button></a></li>
            <li><a href="wydanie_tabela.php"><button>Wydanie</button></li>
            <li><a href="wydawnictwo_tabela.php"><button>Wydawnictwo</button></a></li>
            <li><a href="wypozyczenie_tabela.php"><button>Wypożyczenie</button></a></li>
        </ul>
    </section>
    
    <section id="tabela">
        <?php
        require_once('./../../db_connection.php');
        // Zapytanie SQL
        $sql = "SELECT * FROM czytelnik";
        $result = $conn->query($sql);

        echo "<table>";
        // Nagłówki tabeli
        echo "<thead>
                <tr>
                    <th>ID</th>
                    <th>Imię</th>
                    <th>Nazwisko</th>
                    <th>Numer karty</th>
                    <th>Telefon</th>
                    <th>E-mail</th>
                    <th>Login</th>
                </tr>
            </thead>";
        echo "<tbody>";

        // Sprawdzenie, czy są dane
        if ($result->num_rows > 0) 
        {
            // Wyświetlanie danych
            while ($row = $result->fetch_assoc()) 
            {
                echo "<tr>
                        <td>" . $row["ID"] . "</td>
                        <td>" . $row["imie"] . "</td>
                        <td>" . $row["nazwisko"] . "</td>
                        <td>" . $row["nr_karty"] . "</td>
                        <td>" . $row["telefon"] . "</td>
                        <td>" . $row["email"] . "</td>
                        <td>" . $row["login"] . "</td>
                    </tr>";
            }
        } 
        else 
        {
            // Pusty wiersz z wiadomością
            echo "<tr>
                    <td colspan='7' class='no-data'>Brak danych</td>
                </tr>";
        }
        echo "</tbody>";
        echo "</table>";

        // Zamknięcie połączenia
        $conn->close();
        ?>
    </section>

    <footer>
        <p>&copy; 2024 Biblioteka Online | Wszystkie prawa zastrzeżone</p>
    </footer>
    
    <script src="../../../js/admin.js"></script>
</body>
</html>
